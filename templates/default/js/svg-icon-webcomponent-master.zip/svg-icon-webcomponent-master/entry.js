// this file means to be compiled to lib
import {default as createFn} from "./icon";

// change this if you want a different tag name 
let tagName = "svg-icon";

// run
createFn(tagName)();
